import { redirect } from "react-router-dom";

export function redirector(path) {
  return redirect(path);
}
